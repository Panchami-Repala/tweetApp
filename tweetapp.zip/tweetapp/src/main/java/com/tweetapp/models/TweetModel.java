package com.tweetapp.models;

public class TweetModel {

  private String tweet;
  private String user;

  public TweetModel() {}

  public TweetModel(String tweet, String user) {
    super();
    this.tweet = tweet;
    this.user = user;
  }

  public String getTweet() {
    return tweet;
  }

  public void setTweet(String tweet) {
    this.tweet = tweet;
  }

  public String getUser() {
    return user;
  }

  public void setUser(String user) {
    this.user = user;
  }

  @Override
  public String toString() {
    return ("Post [tweet=" + tweet + ", user=" + user + "]");
  }
}
