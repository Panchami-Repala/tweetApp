package com.tweetapp;

import com.tweetapp.service.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

public class App {

  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("####### Welcome to Tweet App ######");
    System.out.println("Select a Choice:");
    System.out.println("1.Registration");
    System.out.println("2.Login");
    System.out.println("3.Forgot Password");
    System.out.println("4.Exit");

    try {
      int choice = sc.nextInt();
      switch (choice) {
        case 1:
          RegistrationService rs = new RegistrationService();
          rs.doRegistration();
          break;
        case 2:
          LoginService ls = new LoginService();
          ls.dologin();
          break;
        case 3:
          PasswordService ps = new PasswordService();
          ps.forgotPassword();
          main(args);
          break;
        case 4:
          System.out.println("----- Good Bye have a nice day -----");
          break;
      }
    } catch (Exception e) {
      System.out.println("Invalid Choice, Please Select a Choice");
      main(args);
    }
  }
}
