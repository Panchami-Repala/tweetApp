package com.tweetapp.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.*;

public class Database_Connection {

  public Connection getConnection() {
    Connection conn = null;
    try {
      Properties p = new Properties();
      p.load(getClass().getClassLoader().getResourceAsStream("db.properties"));
      conn =
        DriverManager.getConnection(
          p.getProperty("URL") +
          p.getProperty("DBNAME") +
          "?user=" +
          p.getProperty("USER") +
          "&password=" +
          p.getProperty("PASSWORD")
        );
    } catch (Exception e) {
      e.printStackTrace();
    }
    return conn;
  }
}
