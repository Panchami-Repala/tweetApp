package com.tweetapp.service;

import com.tweetapp.App;
import com.tweetapp.dao.*;
import com.tweetapp.models.*;
import com.tweetapp.service.*;
import java.util.*;

public class MenuService {

  Scanner sc = new Scanner(System.in);

  public void useroperations(RegistrationModel rm) {
    System.out.println("####### Welcome " + rm.getFirstName() + " ######");
    System.out.println("Select a Choice:");
    System.out.println("1.Post a tweet");
    System.out.println("2.View my tweets");
    System.out.println("3.View all tweets");
    System.out.println("4.View all users");
    System.out.println("5.Reset password");
    System.out.println("6.Logout");
    TweetService ts = new TweetService();
    int choice = sc.nextInt();
    switch (choice) {
      case 1:
        if (ts.doTweet(rm)) {
          System.out.println("----- Tweet is Posted sucessfully -----");
          useroperations(rm);
        }
        break;
      case 2:
        if (ts.viewTweets(rm)) {
          useroperations(rm);
        }
        break;
      case 3:
        if (ts.viewAllTweets()) {
          useroperations(rm);
        }
        break;
      case 4:
        if (ts.viewAllUsers()) {
          useroperations(rm);
        }
        break;
      case 5:
        PasswordService ps = new PasswordService();
        if (ps.resetPassword(rm)) {
          useroperations(rm);
        }
        break;
      case 6:
        LoginService ls = new LoginService();
        ls.logout(rm);
        App.main(null);
        break;
      default:
        System.out.println("Please Enter correct Choice");
        useroperations(rm);
    }
  }
}
