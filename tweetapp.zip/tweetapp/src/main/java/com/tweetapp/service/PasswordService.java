package com.tweetapp.service;

import com.tweetapp.dao.*;
import com.tweetapp.models.*;
import java.util.*;

public class PasswordService {

  Scanner sc = new Scanner(System.in);

  public boolean resetPassword(RegistrationModel rm) {
    RegistrationDao rd = new RegistrationDao();
    System.out.print("Enter old password => ");
    String oldpassword = sc.nextLine();
    while (oldpassword.length() == 0) {
      System.out.print("Enter old password => ");
      oldpassword = sc.nextLine();
    }
    if (oldpassword.equals(rd.getPassword(rm.getEmailId()))) {
      System.out.print("Enter new password => ");
      String newpassword = sc.nextLine();
      while (newpassword.length() == 0) {
        System.out.print("Enter new password => ");
        newpassword = sc.nextLine();
      }
      rd.resetPassword(rm.getEmailId(), newpassword);
      System.out.println("##### Password updated successfully #####");
    } else {
      System.out.println("##### Please enter correct password #####");
      resetPassword(rm);
    }
    return true;
  }

  public void forgotPassword() {
    ValidationService rs = new ValidationService();
    System.out.print("Enter Email address => ");
    String email = sc.nextLine();

    if (rs.validateEmail(email)) {
      RegistrationDao rd = new RegistrationDao();
      String emailId = rd.forgotPassword(email);
      if (emailId.length() != 0) {
        System.out.print("Please Enter new password => ");

        String passcode = sc.nextLine();
        while (passcode.length() == 0) {
          System.out.println("##### Password should not be empty #####");
          System.out.print("Please Enter new password => ");
          passcode = sc.nextLine();
        }
        if (passcode.length() != 0) {
          if (rd.resetPassword(emailId, passcode)) {
            System.out.println("##### Password Updated Successfully #####");
          }
        }
      } else {
        System.out.println("email does not matched");
        forgotPassword();
      }
    } else {
      System.out.println("Please Enter valid email");
      forgotPassword();
    }
  }
}
