package com.tweetapp.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationService {
	
	  public boolean validateEmail(String email) {
		    String regex = "^(.+)@(.+)$";
		    Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher(email);
		    return matcher.matches();
		  }

		  public String validateField(String field, Scanner sc, String fieldName) {
		    String input = "";
		    while (field.length() == 0) {
		      System.out.print(" Enter " + fieldName + " => ");
		      input = sc.nextLine();
		      field = input;
		    }

		    if (input.length() != 0 && fieldName.equals("emailId")) {
		      if (!validateEmail(input)) {
		        System.out.println("--- Enter Valid Email ----");
		        validateField("", sc, fieldName);
		      }
		    }
		    if (
		      input.length() != 0 &&
		      fieldName.equals("Gender") &&
		      !(input.equals("male") || input.equals("female"))
		    ) {
		      System.out.println("--- Enter Valid Gender ----");
		      validateField("", sc, fieldName);
		    }
		    return input;
		  }

		  public boolean validateDate(String date) {
		    String[] dob = date.split("-");

		    String parseddob = "";
		    for (int i = 0; i < dob.length; i++) {
		      parseddob = parseddob.concat(dob[i] + "/");
		    }
		    parseddob = parseddob.substring(0, parseddob.length() - 1);
		    String regex = "^(1[0-2]|0[1-9])/(3[01]" + "|[12][0-9]|0[1-9])/[0-9]{4}$";
		    Pattern pattern = Pattern.compile(regex);
		    Matcher matcher = pattern.matcher((CharSequence) parseddob);
		    return matcher.matches();
		  }

}
