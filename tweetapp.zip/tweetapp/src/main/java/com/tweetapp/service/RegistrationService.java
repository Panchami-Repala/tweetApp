package com.tweetapp.service;

import com.tweetapp.dao.RegistrationDao;
import com.tweetapp.models.RegistrationModel;
import com.tweetapp.service.LoginService;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class RegistrationService {

	ValidationService validateServcie =new ValidationService();
  public void doRegistration() {
    Scanner scanner = new Scanner(System.in);

    System.out.println("############# REGISTRATION #############");

    String firstName = "";
    firstName = validateServcie.validateField(firstName, scanner, "firstName");
    System.out.print(" Enter lastName => ");
    String lastName = scanner.nextLine();
    String gender = "";
    gender = validateServcie.validateField(gender, scanner, "Gender");
    System.out.print(" Enter dob in MM-dd-yyyy format => ");

    String dob = scanner.nextLine();
    if (dob.length() != 0) {
      while (!validateServcie.validateDate(dob)) {
        dob = validateServcie.validateField(dob, scanner, "dob in MM-dd-yyyy format");
      }
      String[] dbirth = dob.split("-");
      dob = dbirth[2] + "-" + dbirth[0] + "-" + dbirth[1];
    }
    String emailId = "";
    emailId = validateServcie.validateField(emailId, scanner, "emailId");

    String password = "";
    password = validateServcie.validateField(password, scanner, "password");

    RegistrationModel user = new RegistrationModel(
      firstName,
      lastName,
      gender,
      dob,
      emailId,
      password
    );

    RegistrationDao dao = new RegistrationDao();
    if (dao.register(user)) {
      System.out.println(" User Registration is Successful... ");
      System.out.println("Please Login");
      LoginService login = new LoginService();
      login.dologin();
    } else {
      System.out.println("Registration failed - please try with different ID");
      doRegistration();
    }
  }
}
