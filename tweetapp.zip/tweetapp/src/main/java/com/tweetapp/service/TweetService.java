package com.tweetapp.service;

import com.tweetapp.dao.*;
import com.tweetapp.models.*;
import java.util.*;

public class TweetService {

  Scanner sc = new Scanner(System.in);

  public boolean doTweet(RegistrationModel rm) {
    System.out.println("please post a tweet=>");
    String tweet = sc.nextLine();
    if (tweet.length() > 0) {
      TweetModel tm = new TweetModel(tweet, rm.getEmailId());
      TweetDao td = new TweetDao();
      return td.postTweet(tm);
    } else {
      System.out.println("Tweet should not be empty");
      doTweet(rm);
    }
    return true;
  }

  public boolean viewTweets(RegistrationModel rm) {
    TweetDao td = new TweetDao();
    ArrayList<TweetModel> tweets = new ArrayList<TweetModel>();
    tweets = td.viewTweets(rm.getEmailId());
    if (tweets.size() != 0) {
      System.out.println("----- Tweets of " + rm.getFirstName() + " -----");
      for (int i = 0; i < tweets.size(); i++) {
        System.out.println(tweets.get(i).getTweet());
      }
    } else {
      System.out.println("----- No Tweets are available -----");
    }
    return true;
  }

  public boolean viewAllTweets() {
    TweetDao td = new TweetDao();
    ArrayList<TweetModel> tweets = new ArrayList<TweetModel>();
    tweets = td.viewAllTweets();
    if (tweets.size() != 0) {
      System.out.println("----- Tweets of All Users -----");
      ArrayList<String> users = new ArrayList<String>();
      for (int i = 0; i < tweets.size(); i++) {
        if (users.indexOf(tweets.get(i).getUser()) == -1) {
          users.add(tweets.get(i).getUser());
        }
      }
      for (int i = 0; i < users.size(); i++) {
        System.out.println("Tweets of user(" + users.get(i)+")");
        for (int j = 0; j < tweets.size(); j++) {
          if (users.get(i).equals(tweets.get(j).getUser())) {
            System.out.println(tweets.get(j).getTweet());
          }
        }
        System.out.println();
      }
    } else {
      System.out.println("----- No Tweets are available -----");
    }

    return true;
  }

  public boolean viewAllUsers() {
    TweetDao td = new TweetDao();
    System.out.println("----- All Users Details -----");
    ArrayList<RegistrationModel> users = new ArrayList<RegistrationModel>();
    users = td.viewAllUsers();
    String format = "%-20s%-20s%-20s%-20s%-20s%n";
    System.out.printf(
      format,
      "First Name",
      "Last Name",
      "Date of Birth",
      "Gender",
      "Email Id"
    );
    for (int j = 0; j < users.size(); j++) {
      System.out.printf(
        format,
        users.get(j).getFirstName(),
        users.get(j).getLastName(),
        users.get(j).getDob(),
        users.get(j).getGender(),
        users.get(j).getEmailId()
      );
    }
    System.out.println();

    return true;
  }
}
