package com.tweetapp.service;

import com.tweetapp.App;
import com.tweetapp.dao.LoginDao;
import com.tweetapp.models.LoginModel;
import com.tweetapp.models.RegistrationModel;
import com.tweetapp.service.*;
import java.util.*;

public class LoginService {

  Scanner sc = new Scanner(System.in);

  public void dologin() {
    System.out.println("########## LOGIN ##########");
    System.out.print("Enter EmailId => ");
    String emailId = sc.nextLine();
    ValidationService rs = new ValidationService();

    while (!rs.validateEmail(emailId)) {
      System.out.print("Enter Valid EmailId => ");
      emailId = sc.nextLine();
    }
    System.out.print("Enter Password => ");
    String password = sc.nextLine();
    while (password.length() == 0) {
      System.out.print("Enter password => ");
      password = sc.nextLine();
    }
    LoginModel lm = new LoginModel(emailId, password);
    LoginDao ld = new LoginDao();
    RegistrationModel rm = new RegistrationModel();
    rm = ld.login(lm);
    if (rm.getEmailId() != null) {
      MenuService ms = new MenuService();
      ms.useroperations(rm);
    } else {
      System.out.println(" Please Enter Valid Credentials");
      dologin();
    }
  }

  public void logout(RegistrationModel rm) {
    LoginDao ld = new LoginDao();
    ld.setLoginStatus(false, rm.getEmailId());
    System.out.println("Logged out successfully");
  }
}
