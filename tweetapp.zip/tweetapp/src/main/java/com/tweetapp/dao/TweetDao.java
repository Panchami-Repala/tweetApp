package com.tweetapp.dao;

import com.tweetapp.config.Database_Connection;
import com.tweetapp.models.*;
import java.sql.*;
import java.util.*;

public class TweetDao {

  public boolean postTweet(TweetModel tm) {
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      DatabaseMetaData meta = con.getMetaData();
      ResultSet tables = meta.getTables(
        null,
        null,
        "POSTS",
        new String[] { "TABLE" }
      );
      if (tables.next()) {
        PreparedStatement ps = con.prepareStatement(
          "insert into posts(tweet,userId) values(?,?)"
        );
        ps.setString(1, tm.getTweet());
        ps.setString(2, tm.getUser());
        ps.executeUpdate();
        return true;
      } else {
        PreparedStatement ps1 = con.prepareStatement(
          "create table posts(id int auto_increment not null, tweet varchar(200) not null,userId varchar(100) not null, primary key(id), foreign key(userId) references users(email))"
        );
        ps1.executeUpdate();
        PreparedStatement ps = con.prepareStatement(
          "insert into posts(tweet,userId) values(?,?)"
        );
        ps.setString(1, tm.getTweet());
        ps.setString(2, tm.getUser());
        ps.executeUpdate();
        return true;
      }
    } catch (Exception e) {
      // System.out.println(e);
    }
    return false;
  }

  public ArrayList<TweetModel> viewTweets(String user) {
    ArrayList<TweetModel> tweetsList = new ArrayList<TweetModel>();
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement(
        "select tweet from posts where userId=?"
      );
      ps.setString(1, user);
      ResultSet rs = ps.executeQuery();

      while (rs.next()) {
        TweetModel tm = new TweetModel();
        tm.setTweet(rs.getString(1));
        tweetsList.add(tm);
      }
    } catch (Exception e) {
      System.out.println(e);
    }
    return tweetsList;
  }

  public ArrayList<TweetModel> viewAllTweets() {
    ArrayList<TweetModel> tweetsList = new ArrayList<TweetModel>();
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement(
        "select tweet,userId from posts"
      );
      ResultSet rs = ps.executeQuery();

      while (rs.next()) {
        TweetModel tm = new TweetModel();
        tm.setTweet(rs.getString(1));
        tm.setUser(rs.getString(2));
        tweetsList.add(tm);
      }
    } catch (Exception e) {
      System.out.println(e);
    }
    return tweetsList;
  }

  public ArrayList<RegistrationModel> viewAllUsers() {
    ArrayList<RegistrationModel> usersList = new ArrayList<RegistrationModel>();
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement("select * from users");

      ResultSet rs = ps.executeQuery();

      while (rs.next()) {
        RegistrationModel reg = new RegistrationModel();
        reg.setFirstName(rs.getString(1));
        reg.setLastName(rs.getString(2));
        reg.setGender(rs.getString(3));
        reg.setDob(rs.getString(4));
        reg.setEmailId(rs.getString(5));
        reg.setPassword(rs.getString(6));
        usersList.add(reg);
      }
    } catch (Exception e) {
      System.out.println(e);
    }
    return usersList;
  }
}
