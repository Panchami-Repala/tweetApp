package com.tweetapp.dao;

import com.tweetapp.config.Database_Connection;
import com.tweetapp.models.RegistrationModel;
import java.sql.*;

public class RegistrationDao {

  public Date dateconvert(String date) {
    if (date.length() > 0) {
      return java.sql.Date.valueOf(date);
    }
    return null;
  }

  public boolean register(RegistrationModel rm) {
    int stat = 0;
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      DatabaseMetaData meta = con.getMetaData();
      ResultSet tables = meta.getTables(
        null,
        null,
        "USERS",
        new String[] { "TABLE" }
      );
      if (tables.next()) {
        PreparedStatement ps = con.prepareStatement(
          "insert into users values(?,?,?,?,?,?,?)"
        );
        ps.setString(1, rm.getFirstName());
        ps.setString(2, rm.getLastName());
        ps.setString(3, rm.getGender());
        ps.setDate(4, dateconvert(rm.getDob()));
        ps.setString(5, rm.getEmailId());
        ps.setString(6, rm.getPassword());
        ps.setBoolean(7, false);
        stat = ps.executeUpdate();
      } else {
        PreparedStatement ps = con.prepareStatement(
          "create table users (first_name varchar(45) not null, last_name varchar(45), gender varchar(20) not null,dob date,email varchar(100) not null primary key,password varchar(45) not null, login_status boolean)"
        );
        ps.executeUpdate();

        PreparedStatement ps1 = con.prepareStatement(
          "insert into users values(?,?,?,?,?,?,?)"
        );
        ps1.setString(1, rm.getFirstName());
        ps1.setString(2, rm.getLastName());
        ps1.setString(3, rm.getGender());
        ps1.setDate(4, dateconvert(rm.getDob()));
        ps1.setString(5, rm.getEmailId());
        ps1.setString(6, rm.getPassword());
        ps1.setBoolean(7, false);
        stat = ps1.executeUpdate();
      }
    } catch (Exception e) {
      System.out.println(e);
    }
    if (stat == 1) {
      return true;
    }
    return false;
  }

  public boolean resetPassword(String email, String password) {
    int stat = 0;
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement(
        "update users set password=? where email=?"
      );
      ps.setString(1, password);
      ps.setString(2, email);
      stat = ps.executeUpdate();
    } catch (Exception e) {
      // System.out.println(e);
    }
    if (stat == 1) {
      return true;
    }
    return false;
  }

  public String getPassword(String email) {
    String passcode = "";
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement(
        "select password from users where email=?"
      );
      ps.setString(1, email);
      ResultSet rs = ps.executeQuery();

      while (rs.next()) {
        passcode = rs.getString(1);
      }
    } catch (Exception e) {
      //   System.out.println(e);
    }
    return passcode;
  }

  public String forgotPassword(String email) {
    String emailId = "";
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement(
        "select email from users where email=?"
      );
      ps.setString(1, email);
      ResultSet rs = ps.executeQuery();

      while (rs.next()) {
        emailId = rs.getString(1);
      }
    } catch (Exception e) {
      //   System.out.println(e);
    }
    return emailId;
  }
}
