package com.tweetapp.dao;

import com.tweetapp.config.Database_Connection;
import com.tweetapp.models.LoginModel;
import com.tweetapp.models.RegistrationModel;
import java.sql.*;

public class LoginDao {

  public RegistrationModel login(LoginModel lm) {
    RegistrationModel reg = new RegistrationModel();
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement(
        "select * from users where email=? and password=?"
      );
      ps.setString(1, lm.getEmailId());
      ps.setString(2, lm.getPassword());
      ResultSet rs = ps.executeQuery();

      while (rs.next()) {
        reg.setFirstName(rs.getString(1));
        reg.setLastName(rs.getString(2));
        reg.setGender(rs.getString(3));
        reg.setDob(rs.getString(4));
        reg.setEmailId(rs.getString(5));
        reg.setPassword(rs.getString(6));
      }
      if (reg.getEmailId() != null) {
        setLoginStatus(true, reg.getEmailId());
      }
    } catch (Exception e) {
      System.out.println(e);
    }
    return reg;
  }

  public void setLoginStatus(boolean status, String email) {
    try {
      Database_Connection db = new Database_Connection();
      Connection con = db.getConnection();
      PreparedStatement ps = con.prepareStatement(
        "update users set login_status=? where email=?"
      );
      ps.setBoolean(1, status);
      ps.setString(2, email);
      ps.executeUpdate();
    } catch (Exception e) {
      System.out.println(e);
    }
  }
}
